# ACTN – Autonomous Cooperative Testing Network (CRAC)

Status: **Phase 1 – Architecture and Foundation** (Phases 2–7 not yet implemented).

## Claude API analysis
Settings → paste your Anthropic API key (stored server-side in backend/data/secrets.json, never returned to the browser) → Claude Analysis page → pick a project → Analyze. Findings are saved as Unverified candidates.

## What works now
- FastAPI backend, SQLAlchemy models for all 14 required tables (full evidence trail), SQLite (PostgreSQL-compatible URL via `ACTN_DATABASE_URL`)
- Secure upload: size limits, extension allow-list, zip-slip / zip-bomb / symlink protection, SHA-256 de-duplication
- Validated settings API (CRAC weights must sum to 1, ordered risk thresholds, sandbox limits)
- Agent base class (structured messages, retries, failure isolation), registry, 9-agent catalog seeded in DB
- React + Vite + Tailwind SOC-style shell; Dashboard, Upload and Settings pages are wired to the real API
- Other pages are honest placeholders until their backend exists

## Engineering assumptions (not from the paper)
- CRAC: `risk = w1*semantic + w2*dependency + w3*execution_sensitivity`, indicators in [0,1], default weights 0.40/0.35/0.25, thresholds Critical>=0.75, High>=0.55, Medium>=0.35
- Verification formula will be documented in Phase 4

## Run on Windows (PowerShell)
```
cd backend
py -3.11 -m venv .venv; .venv\Scripts\Activate.ps1
pip install -r requirements.txt
python -m pytest
uvicorn app.main:app --reload --port 8000
```
New terminal:
```
cd frontend
npm install
npm run dev      # http://localhost:5173
```
Docker alternative: `docker compose up --build`

Sample vulnerable/safe code for later phases: `datasets/sample_project/`
