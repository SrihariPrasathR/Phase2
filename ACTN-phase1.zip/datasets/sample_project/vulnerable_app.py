import os, sqlite3, pickle, subprocess

DB_PASSWORD = "admin123"  # hardcoded credential (demo)


def get_user(conn, username):
    return conn.execute("SELECT * FROM users WHERE name = '%s'" % username).fetchall()  # SQL injection (demo)


def run_ping(host):
    return subprocess.run("ping -c 1 " + host, shell=True, capture_output=True)  # command injection (demo)


def read_file(base, name):
    return open(os.path.join(base, name)).read()  # path traversal (demo)


def load_blob(data):
    return pickle.loads(data)  # insecure deserialization (demo)
