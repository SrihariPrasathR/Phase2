"""Demo: command injection and unsafe dynamic evaluation."""
import ast, re, subprocess


def ping_vulnerable(host: str) -> str:
    return subprocess.check_output("ping -c 1 " + host, shell=True, text=True)  # VULNERABLE: shell=True + concatenation


def calculate_vulnerable(expression: str):
    return eval(expression)  # VULNERABLE: arbitrary code execution


def archive_vulnerable(folder: str):
    import os
    os.system("tar czf backup.tgz " + folder)  # VULNERABLE: os.system with user input


_HOST = re.compile(r"^[A-Za-z0-9.-]{1,253}$")


def ping_safe(host: str) -> str:
    if not _HOST.match(host):  # SAFE: allow-list validation + argument list, no shell
        raise ValueError("invalid host")
    return subprocess.check_output(["ping", "-c", "1", host], text=True)


def calculate_safe(expression: str):
    return ast.literal_eval(expression)  # SAFE: literals only
