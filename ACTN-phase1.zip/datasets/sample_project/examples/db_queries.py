"""Demo: SQL injection and input validation."""
import sqlite3


def find_user_vulnerable(conn: sqlite3.Connection, username: str):
    query = f"SELECT id, name FROM users WHERE name = '{username}'"  # VULNERABLE: string-built SQL
    return conn.execute(query).fetchall()


def search_orders_vulnerable(conn: sqlite3.Connection, customer: str, status: str):
    sql = "SELECT * FROM orders WHERE customer = '" + customer + "' AND status = '" + status + "'"  # VULNERABLE
    return conn.execute(sql).fetchall()


def find_user_safe(conn: sqlite3.Connection, username: str):
    return conn.execute("SELECT id, name FROM users WHERE name = ?", (username,)).fetchall()  # SAFE: parameterized


def get_order_safe(conn: sqlite3.Connection, order_id: str):
    if not order_id.isdigit():  # SAFE: input validation
        raise ValueError("order_id must be numeric")
    return conn.execute("SELECT * FROM orders WHERE id = ?", (int(order_id),)).fetchone()
