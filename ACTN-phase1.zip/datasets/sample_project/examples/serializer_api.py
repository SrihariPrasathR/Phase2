"""Demo: insecure deserialization and sensitive information exposure."""
import json, logging, pickle

import yaml

log = logging.getLogger("api")


def load_session_vulnerable(blob: bytes):
    return pickle.loads(blob)  # VULNERABLE: untrusted pickle


def load_config_vulnerable(text: str):
    return yaml.load(text, Loader=yaml.Loader)  # VULNERABLE: unsafe YAML loader


def login_vulnerable(user: str, password: str, token: str):
    log.info("login attempt user=%s password=%s token=%s", user, password, token)  # VULNERABLE: secrets in logs
    return {"user": user, "password": password}  # VULNERABLE: returns the password


def load_session_safe(blob: bytes):
    return json.loads(blob.decode("utf-8"))  # SAFE: data-only format


def load_config_safe(text: str):
    return yaml.safe_load(text)  # SAFE


def login_safe(user: str, token: str):
    log.info("login attempt user=%s", user)  # SAFE: no secrets logged
    return {"user": user}
