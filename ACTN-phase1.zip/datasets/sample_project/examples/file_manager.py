"""Demo: path traversal and insecure file handling."""
import os, tempfile

BASE_DIR = "/srv/app/uploads"


def read_upload_vulnerable(filename: str) -> str:
    with open(os.path.join(BASE_DIR, filename)) as fh:  # VULNERABLE: '../' escapes BASE_DIR
        return fh.read()


def save_report_vulnerable(name: str, text: str) -> str:
    path = tempfile.mktemp(suffix=name)  # VULNERABLE: race-prone insecure temp file
    open(path, "w").write(text)
    os.chmod(path, 0o777)                # VULNERABLE: world-writable permissions
    return path


def read_upload_safe(filename: str) -> str:
    root = os.path.realpath(BASE_DIR)
    path = os.path.realpath(os.path.join(root, filename))
    if not path.startswith(root + os.sep):  # SAFE: containment check
        raise PermissionError("path outside upload directory")
    with open(path) as fh:
        return fh.read()


def save_report_safe(text: str) -> str:
    fd, path = tempfile.mkstemp(suffix=".txt")  # SAFE: atomic, mode 0600
    with os.fdopen(fd, "w") as fh:
        fh.write(text)
    return path
