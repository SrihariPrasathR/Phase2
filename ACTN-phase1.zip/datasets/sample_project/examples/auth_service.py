"""Demo: authentication weaknesses. Intentionally flawed functions are marked VULNERABLE; SAFE ones are controls."""
import hashlib, hmac, os, secrets

ADMIN_USER = "admin"
ADMIN_PASSWORD = "Passw0rd!2024"          # VULNERABLE: hardcoded credential
API_SECRET_KEY = "sk_live_51H8xAMPLEKEY"  # VULNERABLE: hardcoded secret


def hash_password_weak(password: str) -> str:
    return hashlib.md5(password.encode()).hexdigest()  # VULNERABLE: weak, unsalted hash


def check_login_weak(user: str, password: str) -> bool:
    return user == ADMIN_USER and password == ADMIN_PASSWORD  # VULNERABLE: hardcoded creds, non-constant-time compare


def hash_password(password: str, salt: bytes | None = None) -> tuple[bytes, bytes]:
    salt = salt or os.urandom(16)  # SAFE: random salt + PBKDF2
    return salt, hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 200_000)


def verify_password(password: str, salt: bytes, expected: bytes) -> bool:
    _, digest = hash_password(password, salt)
    return hmac.compare_digest(digest, expected)  # SAFE: constant-time comparison


def new_session_token() -> str:
    return secrets.token_urlsafe(32)  # SAFE: CSPRNG
