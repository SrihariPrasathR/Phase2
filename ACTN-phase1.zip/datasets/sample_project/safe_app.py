import os, sqlite3, subprocess, json


def get_user(conn, username):
    return conn.execute("SELECT * FROM users WHERE name = ?", (username,)).fetchall()


def run_ping(host):
    if not host.replace(".", "").isalnum():
        raise ValueError("invalid host")
    return subprocess.run(["ping", "-c", "1", host], capture_output=True)


def read_file(base, name):
    path = os.path.realpath(os.path.join(base, name))
    if not path.startswith(os.path.realpath(base) + os.sep):
        raise PermissionError("outside base directory")
    return open(path).read()


def load_blob(data):
    return json.loads(data)
