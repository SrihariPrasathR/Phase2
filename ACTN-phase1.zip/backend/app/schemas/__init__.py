from datetime import datetime
from pydantic import BaseModel, ConfigDict


class ORM(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class SourceFileOut(ORM):
    id: int
    relative_path: str
    language: str
    size_bytes: int
    line_count: int
    sha256: str


class JobOut(ORM):
    id: int
    project_id: int
    status: str
    current_stage: str | None
    created_at: datetime


class ProjectOut(ORM):
    id: int
    name: str
    language: str
    created_at: datetime
    file_count: int = 0
    latest_job: JobOut | None = None


class UploadResult(BaseModel):
    project: ProjectOut
    job: JobOut
    ingestion: dict
