from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker
from .config import settings


class Base(DeclarativeBase):
    pass


_args = {"check_same_thread": False} if settings.database_url.startswith("sqlite") else {}
engine = create_engine(settings.database_url, connect_args=_args)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db() -> None:
    from . import models  # noqa: F401  (register tables)
    from .agents.registry import AGENT_CATALOG
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        existing = {a.key for a in db.query(models.Agent).all()}
        for key, name, desc in AGENT_CATALOG:
            if key not in existing:
                db.add(models.Agent(key=key, name=name, description=desc))
        db.commit()
