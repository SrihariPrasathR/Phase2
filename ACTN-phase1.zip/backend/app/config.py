"""Application configuration (env vars prefixed ACTN_, or a .env file)."""
from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parents[2]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="ACTN_", env_file=".env", extra="ignore")

    database_url: str = f"sqlite:///{(BASE_DIR / 'data' / 'actn.db').as_posix()}"
    data_dir: Path = BASE_DIR / "data"
    cors_origins: list[str] = ["http://localhost:5173", "http://127.0.0.1:5173"]

    # Upload security limits
    max_upload_bytes: int = 25 * 1024 * 1024        # per uploaded file / archive
    max_file_bytes: int = 2 * 1024 * 1024           # per extracted source file
    max_archive_entries: int = 2000
    max_uncompressed_bytes: int = 100 * 1024 * 1024  # total extracted size (zip-bomb guard)


settings = Settings()
settings.data_dir.mkdir(parents=True, exist_ok=True)
