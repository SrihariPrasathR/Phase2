from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from sqlalchemy import func
from sqlalchemy.orm import Session
from ..agents.registry import AGENT_CATALOG
from ..config import settings as app_config
from ..database import get_db
from ..models import (Agent, AnalysisJob, GeneratedTest, Project, SandboxExecution, SourceFile,
                      VerificationResult, VulnerabilityCandidate)
from ..schemas import JobOut, ProjectOut, SourceFileOut, UploadResult
from ..services import ingestion
from ..services.settings_service import AppSettings, load_settings, save_settings

router = APIRouter(prefix="/api")


def _project_out(db: Session, p: Project) -> ProjectOut:
    job = db.query(AnalysisJob).filter_by(project_id=p.id).order_by(AnalysisJob.id.desc()).first()
    count = db.query(func.count(SourceFile.id)).filter_by(project_id=p.id).scalar()
    return ProjectOut(id=p.id, name=p.name, language=p.language, created_at=p.created_at, file_count=count,
                      latest_job=JobOut.model_validate(job) if job else None)


@router.get("/health")
def health():
    return {"status": "ok"}


@router.post("/projects", response_model=UploadResult, status_code=201)
async def create_project(name: str = Form(..., min_length=1, max_length=200), language: str = Form("python"),
                         files: list[UploadFile] = File(...), db: Session = Depends(get_db)):
    cfg = load_settings()
    if language not in cfg.supported_languages:
        raise HTTPException(400, f"Language '{language}' is not enabled. Enabled: {cfg.supported_languages}")
    uploads = []
    for f in files:
        data = await f.read(app_config.max_upload_bytes + 1)
        uploads.append((f.filename or "upload", data))
    project = Project(name=name.strip(), language=language)
    db.add(project)
    db.flush()
    try:
        info = ingestion.ingest(db, project, uploads)
    except ingestion.UploadError as exc:
        db.rollback()
        raise HTTPException(400, str(exc)) from exc
    job = AnalysisJob(project_id=project.id, status="pending", config_snapshot=cfg.model_dump())
    db.add(job)
    db.commit()
    return UploadResult(project=_project_out(db, project), job=JobOut.model_validate(job), ingestion=info)


@router.get("/projects", response_model=list[ProjectOut])
def list_projects(db: Session = Depends(get_db)):
    return [_project_out(db, p) for p in db.query(Project).order_by(Project.id.desc()).all()]


@router.get("/projects/{project_id}", response_model=ProjectOut)
def get_project(project_id: int, db: Session = Depends(get_db)):
    p = db.get(Project, project_id)
    if not p:
        raise HTTPException(404, "Project not found")
    return _project_out(db, p)


@router.get("/projects/{project_id}/files", response_model=list[SourceFileOut])
def project_files(project_id: int, db: Session = Depends(get_db)):
    return db.query(SourceFile).filter_by(project_id=project_id).order_by(SourceFile.relative_path).all()


@router.get("/files/{file_id}")
def file_content(file_id: int, db: Session = Depends(get_db)):
    f = db.get(SourceFile, file_id)
    if not f:
        raise HTTPException(404, "File not found")
    with open(f.storage_path, encoding="utf-8", errors="replace") as fh:
        return {"id": f.id, "path": f.relative_path, "language": f.language, "content": fh.read()}


@router.get("/jobs/{job_id}", response_model=JobOut)
def get_job(job_id: int, db: Session = Depends(get_db)):
    job = db.get(AnalysisJob, job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    return job


@router.get("/agents")
def list_agents(db: Session = Depends(get_db)):
    return [{"key": a.key, "name": a.name, "description": a.description, "status": "idle"}
            for a in db.query(Agent).order_by(Agent.id)]


@router.get("/dashboard/stats")
def dashboard_stats(db: Session = Depends(get_db)):
    q = lambda m, *f: db.query(func.count(m.id)).filter(*f).scalar()  # noqa: E731
    latest = {}
    for v in db.query(VerificationResult).order_by(VerificationResult.id):
        latest[v.candidate_id] = v.final_status
    statuses = list(latest.values())
    by_sev = dict(db.query(VulnerabilityCandidate.severity, func.count(VulnerabilityCandidate.id))
                  .group_by(VulnerabilityCandidate.severity).all())
    by_cat = dict(db.query(VulnerabilityCandidate.category, func.count(VulnerabilityCandidate.id))
                  .group_by(VulnerabilityCandidate.category).all())
    return {
        "by_severity": by_sev, "by_category": by_cat,
        "projects": q(Project), "files": q(SourceFile),
        "vulnerabilities": q(VulnerabilityCandidate),
        "confirmed": statuses.count("Confirmed Vulnerability"),
        "potential": statuses.count("Potential Vulnerability"),
        "false_positives": statuses.count("False Positive"),
        "tests_generated": q(GeneratedTest),
        "tests_passed": q(SandboxExecution, SandboxExecution.status == "passed"),
        "tests_failed": q(SandboxExecution, SandboxExecution.status.in_(["failed", "error", "timeout"])),
        "agents": len(AGENT_CATALOG),
    }


@router.get("/settings", response_model=AppSettings)
def get_settings():
    return load_settings()


@router.put("/settings", response_model=AppSettings)
def put_settings(new: AppSettings):
    return save_settings(new)
