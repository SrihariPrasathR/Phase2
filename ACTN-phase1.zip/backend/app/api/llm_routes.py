from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import AnalysisJob, Project, SourceFile, VulnerabilityCandidate
from ..services import llm_service
from ..services.settings_service import load_settings

router = APIRouter(prefix="/api")
MAX_FILES = 25


class KeyIn(BaseModel):
    api_key: str


@router.get("/settings/llm-key")
def key_status():
    return llm_service.key_status()


@router.put("/settings/llm-key")
def set_key(body: KeyIn):
    try:
        llm_service.set_key(body.api_key)
    except llm_service.LLMError as exc:
        raise HTTPException(400, str(exc)) from exc
    return llm_service.key_status()


@router.delete("/settings/llm-key")
def delete_key():
    llm_service.clear_key()
    return llm_service.key_status()


@router.post("/projects/{project_id}/llm-analysis")
def run_llm_analysis(project_id: int, db: Session = Depends(get_db)):
    project = db.get(Project, project_id)
    if not project:
        raise HTTPException(404, "Project not found")
    key = llm_service.get_key()
    if not key:
        raise HTTPException(400, "No Claude API key configured. Add one in Settings.")
    model = load_settings().llm.model
    files = db.query(SourceFile).filter_by(project_id=project_id).order_by(SourceFile.id).limit(MAX_FILES).all()
    job = AnalysisJob(project_id=project_id, status="running", current_stage="llm_analysis",
                      config_snapshot={"mode": "llm", "model": model})
    db.add(job)
    db.flush()
    found, errors = 0, []
    for f in files:
        try:
            with open(f.storage_path, encoding="utf-8", errors="replace") as fh:
                content = fh.read()
            lines = content.splitlines()
            for item in llm_service.analyze_source(f.relative_path, content, model, key):
                db.add(VulnerabilityCandidate(
                    job_id=job.id, source_file_id=f.id, function_name=item.function, line_number=item.line,
                    category=item.category, description=item.description, severity=item.severity,
                    detection_confidence=item.confidence, detected_by=f"llm:{model}", status="Unverified",
                    evidence={"code": lines[item.line - 1].strip(), "rationale": item.rationale,
                              "remediation": item.remediation}))
                found += 1
        except llm_service.LLMError as exc:
            errors.append({"file": f.relative_path, "error": str(exc)})
    job.status = "completed" if not errors or found else "failed"
    job.current_stage = None
    job.finished_at = datetime.utcnow()
    db.commit()
    return {"job_id": job.id, "model": model, "files_analyzed": len(files), "findings": found, "errors": errors}


@router.get("/projects/{project_id}/findings")
def list_findings(project_id: int, db: Session = Depends(get_db)):
    rows = (db.query(VulnerabilityCandidate, SourceFile).join(SourceFile, SourceFile.id == VulnerabilityCandidate.source_file_id)
            .filter(SourceFile.project_id == project_id).order_by(VulnerabilityCandidate.id).all())
    return [{"id": c.id, "file": f.relative_path, "line": c.line_number, "function": c.function_name,
             "category": c.category, "severity": c.severity, "confidence": c.detection_confidence,
             "description": c.description, "status": c.status, "detected_by": c.detected_by, **c.evidence}
            for c, f in rows]
