"""Persisted analysis settings. CRAC weights are an ENGINEERING ASSUMPTION (the paper gives no numeric weights):
risk = w1*semantic_relevance + w2*dependency_exposure + w3*execution_sensitivity, all indicators in [0,1]."""
import json
from pydantic import BaseModel, Field, model_validator
from ..config import settings


class CracWeights(BaseModel):
    semantic_relevance: float = Field(0.40, ge=0, le=1)
    dependency_exposure: float = Field(0.35, ge=0, le=1)
    execution_sensitivity: float = Field(0.25, ge=0, le=1)

    @model_validator(mode="after")
    def _sum_to_one(self):
        total = self.semantic_relevance + self.dependency_exposure + self.execution_sensitivity
        if abs(total - 1.0) > 1e-6:
            raise ValueError("CRAC weights must sum to 1.0")
        return self


class RiskThresholds(BaseModel):
    critical: float = 0.75
    high: float = 0.55
    medium: float = 0.35

    @model_validator(mode="after")
    def _ordered(self):
        if not (1 >= self.critical > self.high > self.medium > 0):
            raise ValueError("Thresholds must satisfy 1 >= critical > high > medium > 0")
        return self


class SandboxLimits(BaseModel):
    cpu_limit: float = Field(0.5, gt=0, le=4)
    memory_mb: int = Field(256, ge=64, le=2048)
    timeout_seconds: int = Field(30, ge=1, le=300)
    network_enabled: bool = False


class LLMConfig(BaseModel):
    provider: str = "anthropic"
    model: str = "claude-sonnet-5-5"


class AppSettings(BaseModel):
    crac_weights: CracWeights = CracWeights()
    risk_thresholds: RiskThresholds = RiskThresholds()
    sandbox: SandboxLimits = SandboxLimits()
    llm: LLMConfig = LLMConfig()
    supported_languages: list[str] = ["python"]


def _path():
    return settings.data_dir / "settings.json"


def load_settings() -> AppSettings:
    p = _path()
    return AppSettings.model_validate_json(p.read_text()) if p.exists() else AppSettings()


def save_settings(new: AppSettings) -> AppSettings:
    _path().write_text(json.dumps(new.model_dump(), indent=2))
    return new
