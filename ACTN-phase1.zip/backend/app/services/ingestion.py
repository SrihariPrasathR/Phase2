"""Secure upload ingestion: size limits, extension allow-list, zip-slip/zip-bomb/symlink protection, de-duplication."""
import hashlib
import io
import shutil
import zipfile
from pathlib import PurePosixPath
from sqlalchemy.orm import Session
from ..config import settings
from ..models import Project, SourceFile

LANG_BY_EXT = {".py": "python", ".js": "javascript", ".jsx": "javascript", ".ts": "typescript", ".tsx": "typescript",
               ".java": "java", ".php": "php", ".go": "go", ".c": "c", ".cpp": "cpp", ".rb": "ruby"}


class UploadError(ValueError):
    pass


def safe_relative_path(name: str) -> str:
    name = name.replace("\\", "/")
    p = PurePosixPath(name)
    if p.is_absolute() or ".." in p.parts or not p.parts or ":" in p.parts[0]:
        raise UploadError(f"Unsafe path rejected: {name!r}")
    return p.as_posix()


def _ext(rel: str) -> str:
    return PurePosixPath(rel).suffix.lower()


def _iter_zip(data: bytes):
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile as exc:
        raise UploadError("Invalid ZIP archive") from exc
    infos = [i for i in zf.infolist() if not i.is_dir()]
    if len(infos) > settings.max_archive_entries:
        raise UploadError("Archive contains too many entries")
    if sum(i.file_size for i in infos) > settings.max_uncompressed_bytes:
        raise UploadError("Archive expands beyond the allowed size")
    for info in infos:
        if (info.external_attr >> 16) & 0o170000 == 0o120000:
            continue  # symlink: never followed
        rel = safe_relative_path(info.filename)
        if _ext(rel) not in LANG_BY_EXT or info.file_size > settings.max_file_bytes:
            continue
        with zf.open(info) as fh:
            content = fh.read(settings.max_file_bytes + 1)
        if len(content) <= settings.max_file_bytes:
            yield rel, content


def ingest(db: Session, project: Project, uploads: list[tuple[str, bytes]]) -> dict:
    root = (settings.data_dir / "uploads" / str(project.id)).resolve()
    root.mkdir(parents=True, exist_ok=True)
    seen: set[str] = set()
    stored = dupes = skipped = 0
    entries: list[tuple[str, bytes]] = []
    for filename, data in uploads:
        if len(data) > settings.max_upload_bytes:
            raise UploadError(f"{filename} exceeds the upload size limit")
        rel = safe_relative_path(PurePosixPath(filename.replace("\\", "/")).name)  # top-level upload: basename only
        if _ext(rel) == ".zip":
            entries.extend(_iter_zip(data))
        elif _ext(rel) in LANG_BY_EXT and len(data) <= settings.max_file_bytes:
            entries.append((rel, data))
        else:
            skipped += 1
    for rel, content in entries:
        digest = hashlib.sha256(content).hexdigest()
        if digest in seen:
            dupes += 1
            continue
        seen.add(digest)
        dest = (root / rel).resolve()
        if root not in dest.parents:
            raise UploadError(f"Path escape blocked: {rel}")
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(content)
        text = content.decode("utf-8", errors="replace")
        db.add(SourceFile(project_id=project.id, relative_path=rel, language=LANG_BY_EXT[_ext(rel)], sha256=digest,
                          size_bytes=len(content), line_count=text.count("\n") + 1, storage_path=str(dest)))
        stored += 1
    if stored == 0:
        shutil.rmtree(root, ignore_errors=True)
        raise UploadError("No supported source files found in the upload")
    return {"stored": stored, "duplicates_removed": dupes, "skipped": skipped}
