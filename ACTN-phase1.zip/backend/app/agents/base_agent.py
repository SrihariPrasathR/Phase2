"""Agent contract: structured messages in/out, status tracking, timing, retries, error capture."""
import time
import traceback
import uuid
from abc import ABC, abstractmethod
from datetime import datetime
from enum import Enum
from typing import Any
from pydantic import BaseModel, Field


class AgentStatus(str, Enum):
    IDLE = "idle"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class AgentMessage(BaseModel):
    id: str = Field(default_factory=lambda: uuid.uuid4().hex)
    sender: str
    recipient: str
    kind: str                      # e.g. "candidates", "reassess_request"
    payload: dict[str, Any] = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class AgentResult(BaseModel):
    agent: str
    status: AgentStatus
    attempt: int = 1
    duration_ms: float = 0.0
    output_summary: dict[str, Any] = Field(default_factory=dict)
    messages: list[AgentMessage] = Field(default_factory=list)  # messages emitted to other agents
    error: str | None = None


class ProjectContext(BaseModel):
    """Shared state passed between agents (grows as the pipeline advances)."""
    project_id: int
    job_id: int
    config: dict[str, Any] = Field(default_factory=dict)
    artifacts: dict[str, Any] = Field(default_factory=dict)
    log: list[str] = Field(default_factory=list)


class BaseAgent(ABC):
    key: str = ""
    name: str = ""
    description: str = ""
    max_retries: int = 2

    def __init__(self) -> None:
        self.status = AgentStatus.IDLE
        self.current_task: str | None = None

    @abstractmethod
    def process(self, ctx: ProjectContext, inbox: list[AgentMessage]) -> tuple[dict[str, Any], list[AgentMessage]]:
        """Do the work. Return (output_summary, outgoing_messages)."""

    def run(self, ctx: ProjectContext, inbox: list[AgentMessage] | None = None) -> AgentResult:
        inbox = inbox or []
        last_err: str | None = None
        for attempt in range(1, self.max_retries + 2):
            self.status, self.current_task = AgentStatus.RUNNING, f"{self.name} (attempt {attempt})"
            t0 = time.perf_counter()
            try:
                summary, out = self.process(ctx, inbox)
                self.status, self.current_task = AgentStatus.COMPLETED, None
                ctx.log.append(f"[{self.key}] completed in attempt {attempt}")
                return AgentResult(agent=self.key, status=self.status, attempt=attempt,
                                   duration_ms=(time.perf_counter() - t0) * 1000,
                                   output_summary=summary, messages=out)
            except Exception as exc:  # noqa: BLE001 - agents must never crash the orchestrator
                last_err = f"{type(exc).__name__}: {exc}\n{traceback.format_exc(limit=3)}"
                ctx.log.append(f"[{self.key}] attempt {attempt} failed: {type(exc).__name__}")
        self.status, self.current_task = AgentStatus.FAILED, None
        return AgentResult(agent=self.key, status=self.status, attempt=self.max_retries + 1, error=last_err)
