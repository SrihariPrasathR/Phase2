from .base_agent import BaseAgent

# (key, display name, description) - seeded into the `agents` table at startup
AGENT_CATALOG = [
    ("preprocessing", "Preprocessing Agent", "Extracts, deduplicates, normalizes and parses source code"),
    ("static_analysis", "Static Analysis Agent", "Detects suspicious patterns and produces vulnerability candidates"),
    ("semantic_analysis", "Semantic Analysis Agent", "Assesses behavior, purpose and input data flows"),
    ("dependency", "Dependency Analysis Agent", "Builds NetworkX call/data dependency graphs"),
    ("crac", "CRAC Risk Prioritization Agent", "Contextual Risk-Guided Agent Coordination scoring"),
    ("test_generation", "Test Generation Agent", "Generates pytest/Hypothesis tests per candidate"),
    ("sandbox", "Sandbox Execution Agent", "Runs tests in an isolated Docker sandbox"),
    ("verification", "Evidence Verification Agent", "Decides verification status from runtime evidence"),
    ("report", "Report Generation Agent", "Produces PDF/JSON security reports"),
]


class AgentRegistry:
    def __init__(self) -> None:
        self._agents: dict[str, BaseAgent] = {}

    def register(self, agent: BaseAgent) -> None:
        if not agent.key:
            raise ValueError("Agent must define a key")
        self._agents[agent.key] = agent

    def get(self, key: str) -> BaseAgent:
        return self._agents[key]

    def all(self) -> list[BaseAgent]:
        return list(self._agents.values())


registry = AgentRegistry()
