"""Relational model preserving the full evidence trail:
candidate -> risk assessment -> generated test -> sandbox execution -> runtime evidence -> verification."""
from datetime import datetime
from sqlalchemy import JSON, DateTime, Float, ForeignKey, Integer, String, Text, Boolean
from sqlalchemy.orm import Mapped, mapped_column, relationship
from ..database import Base


def _now() -> datetime:
    return datetime.utcnow()


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(String(80), unique=True)
    email: Mapped[str | None] = mapped_column(String(200))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)
    projects: Mapped[list["Project"]] = relationship(back_populates="owner")


class Project(Base):
    __tablename__ = "projects"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(200))
    language: Mapped[str] = mapped_column(String(40), default="python")
    owner_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)
    owner: Mapped[User | None] = relationship(back_populates="projects")
    files: Mapped[list["SourceFile"]] = relationship(back_populates="project", cascade="all, delete-orphan")
    jobs: Mapped[list["AnalysisJob"]] = relationship(back_populates="project", cascade="all, delete-orphan")


class SourceFile(Base):
    __tablename__ = "source_files"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"))
    relative_path: Mapped[str] = mapped_column(String(500))
    language: Mapped[str] = mapped_column(String(40))
    sha256: Mapped[str] = mapped_column(String(64), index=True)
    size_bytes: Mapped[int] = mapped_column(Integer)
    line_count: Mapped[int] = mapped_column(Integer)
    storage_path: Mapped[str] = mapped_column(String(800))
    function_count: Mapped[int] = mapped_column(Integer, default=0)
    project: Mapped[Project] = relationship(back_populates="files")


class AnalysisJob(Base):
    __tablename__ = "analysis_jobs"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"))
    status: Mapped[str] = mapped_column(String(30), default="pending")  # pending|running|completed|failed
    current_stage: Mapped[str | None] = mapped_column(String(60))
    config_snapshot: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime)
    project: Mapped[Project] = relationship(back_populates="jobs")
    executions: Mapped[list["AgentExecution"]] = relationship(back_populates="job", cascade="all, delete-orphan")
    candidates: Mapped[list["VulnerabilityCandidate"]] = relationship(back_populates="job", cascade="all, delete-orphan")


class Agent(Base):
    __tablename__ = "agents"
    id: Mapped[int] = mapped_column(primary_key=True)
    key: Mapped[str] = mapped_column(String(60), unique=True)
    name: Mapped[str] = mapped_column(String(120))
    description: Mapped[str] = mapped_column(Text, default="")


class AgentExecution(Base):
    __tablename__ = "agent_executions"
    id: Mapped[int] = mapped_column(primary_key=True)
    job_id: Mapped[int] = mapped_column(ForeignKey("analysis_jobs.id"))
    agent_id: Mapped[int] = mapped_column(ForeignKey("agents.id"))
    status: Mapped[str] = mapped_column(String(30), default="idle")
    attempt: Mapped[int] = mapped_column(Integer, default=1)
    input_summary: Mapped[dict] = mapped_column(JSON, default=dict)
    output_summary: Mapped[dict] = mapped_column(JSON, default=dict)
    error: Mapped[str | None] = mapped_column(Text)
    messages: Mapped[list] = mapped_column(JSON, default=list)  # structured message history
    started_at: Mapped[datetime | None] = mapped_column(DateTime)
    duration_ms: Mapped[float | None] = mapped_column(Float)
    job: Mapped[AnalysisJob] = relationship(back_populates="executions")
    agent: Mapped[Agent] = relationship()


class VulnerabilityCandidate(Base):
    __tablename__ = "vulnerability_candidates"
    id: Mapped[int] = mapped_column(primary_key=True)
    job_id: Mapped[int] = mapped_column(ForeignKey("analysis_jobs.id"))
    source_file_id: Mapped[int] = mapped_column(ForeignKey("source_files.id"))
    function_name: Mapped[str | None] = mapped_column(String(200))
    line_number: Mapped[int] = mapped_column(Integer)
    category: Mapped[str] = mapped_column(String(80))
    description: Mapped[str] = mapped_column(Text)
    severity: Mapped[str] = mapped_column(String(20))
    detection_confidence: Mapped[float] = mapped_column(Float)
    evidence: Mapped[dict] = mapped_column(JSON, default=dict)
    detected_by: Mapped[str] = mapped_column(String(60))
    status: Mapped[str] = mapped_column(String(40), default="Unverified")
    job: Mapped[AnalysisJob] = relationship(back_populates="candidates")
    source_file: Mapped[SourceFile] = relationship()
    risk: Mapped["RiskAssessment | None"] = relationship(back_populates="candidate", uselist=False, cascade="all, delete-orphan")
    tests: Mapped[list["GeneratedTest"]] = relationship(back_populates="candidate", cascade="all, delete-orphan")
    verifications: Mapped[list["VerificationResult"]] = relationship(back_populates="candidate", cascade="all, delete-orphan")


class DependencyRelationship(Base):
    __tablename__ = "dependency_relationships"
    id: Mapped[int] = mapped_column(primary_key=True)
    job_id: Mapped[int] = mapped_column(ForeignKey("analysis_jobs.id"))
    source_symbol: Mapped[str] = mapped_column(String(300))
    target_symbol: Mapped[str] = mapped_column(String(300))
    kind: Mapped[str] = mapped_column(String(30))  # call | data | control | import
    file_id: Mapped[int | None] = mapped_column(ForeignKey("source_files.id"))
    line_number: Mapped[int | None] = mapped_column(Integer)


class RiskAssessment(Base):
    __tablename__ = "risk_assessments"
    id: Mapped[int] = mapped_column(primary_key=True)
    candidate_id: Mapped[int] = mapped_column(ForeignKey("vulnerability_candidates.id"), unique=True)
    semantic_relevance: Mapped[float] = mapped_column(Float)
    dependency_exposure: Mapped[float] = mapped_column(Float)
    execution_sensitivity: Mapped[float] = mapped_column(Float)
    weights: Mapped[dict] = mapped_column(JSON, default=dict)
    risk_score: Mapped[float] = mapped_column(Float)
    risk_level: Mapped[str] = mapped_column(String(20))
    revision: Mapped[int] = mapped_column(Integer, default=1)  # bumped by runtime feedback
    candidate: Mapped[VulnerabilityCandidate] = relationship(back_populates="risk")


class GeneratedTest(Base):
    __tablename__ = "generated_tests"
    id: Mapped[int] = mapped_column(primary_key=True)
    candidate_id: Mapped[int] = mapped_column(ForeignKey("vulnerability_candidates.id"))
    category: Mapped[str] = mapped_column(String(60))
    code: Mapped[str] = mapped_column(Text)
    expected_behavior: Mapped[str] = mapped_column(Text)
    actual_result: Mapped[str | None] = mapped_column(Text)
    risk_score: Mapped[float | None] = mapped_column(Float)
    candidate: Mapped[VulnerabilityCandidate] = relationship(back_populates="tests")
    executions: Mapped[list["SandboxExecution"]] = relationship(back_populates="test", cascade="all, delete-orphan")


class SandboxExecution(Base):
    __tablename__ = "sandbox_executions"
    id: Mapped[int] = mapped_column(primary_key=True)
    test_id: Mapped[int] = mapped_column(ForeignKey("generated_tests.id"))
    status: Mapped[str] = mapped_column(String(30))  # passed|failed|error|timeout
    exit_code: Mapped[int | None] = mapped_column(Integer)
    stdout: Mapped[str] = mapped_column(Text, default="")
    stderr: Mapped[str] = mapped_column(Text, default="")
    duration_ms: Mapped[float | None] = mapped_column(Float)
    limits: Mapped[dict] = mapped_column(JSON, default=dict)
    test: Mapped[GeneratedTest] = relationship(back_populates="executions")
    evidence: Mapped[list["RuntimeEvidence"]] = relationship(back_populates="execution", cascade="all, delete-orphan")


class RuntimeEvidence(Base):
    __tablename__ = "runtime_evidence"
    id: Mapped[int] = mapped_column(primary_key=True)
    execution_id: Mapped[int] = mapped_column(ForeignKey("sandbox_executions.id"))
    kind: Mapped[str] = mapped_column(String(60))  # exception | anomaly | unsafe_call | output_leak ...
    detail: Mapped[str] = mapped_column(Text)
    supports_vulnerability: Mapped[bool] = mapped_column(Boolean, default=False)
    execution: Mapped[SandboxExecution] = relationship(back_populates="evidence")


class VerificationResult(Base):
    __tablename__ = "verification_results"
    id: Mapped[int] = mapped_column(primary_key=True)
    candidate_id: Mapped[int] = mapped_column(ForeignKey("vulnerability_candidates.id"))
    verification_score: Mapped[float] = mapped_column(Float)
    final_status: Mapped[str] = mapped_column(String(40))
    rationale: Mapped[dict] = mapped_column(JSON, default=dict)
    round: Mapped[int] = mapped_column(Integer, default=1)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)
    candidate: Mapped[VulnerabilityCandidate] = relationship(back_populates="verifications")


class SecurityReport(Base):
    __tablename__ = "security_reports"
    id: Mapped[int] = mapped_column(primary_key=True)
    job_id: Mapped[int] = mapped_column(ForeignKey("analysis_jobs.id"))
    summary: Mapped[dict] = mapped_column(JSON, default=dict)
    json_path: Mapped[str | None] = mapped_column(String(800))
    pdf_path: Mapped[str | None] = mapped_column(String(800))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)
