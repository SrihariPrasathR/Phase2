import io, json, zipfile
from app.services import llm_service

KEY = "sk-ant-test-0123456789abcdefghij"


def _project(client, code="import os\ndef f(x):\n    os.system('ls ' + x)\n"):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("m.py", code)
    r = client.post("/api/projects", data={"name": "llm"}, files=[("files", ("p.zip", buf.getvalue()))])
    return r.json()["project"]["id"]


def test_no_key_returns_400(client):
    llm_service.clear_key()
    assert client.post(f"/api/projects/{_project(client)}/llm-analysis").status_code == 400


def test_key_is_never_returned(client):
    r = client.put("/api/settings/llm-key", json={"api_key": KEY})
    assert r.json() == {"configured": True, "hint": "…ghij"}
    assert KEY not in client.get("/api/settings").text and KEY not in client.get("/api/settings/llm-key").text
    assert client.put("/api/settings/llm-key", json={"api_key": "short"}).status_code == 400


def test_analysis_persists_unverified_and_drops_bad_lines(client, monkeypatch):
    client.put("/api/settings/llm-key", json={"api_key": KEY})
    reply = json.dumps([
        {"line": 3, "function": "f", "category": "Command Injection", "severity": "high", "confidence": 0.9,
         "description": "os.system with user input", "rationale": "concat", "remediation": "use subprocess list"},
        {"line": 999, "category": "Command Injection", "severity": "High", "confidence": 0.5, "description": "ghost"},
        {"line": 1, "category": "Made Up", "severity": "High", "confidence": 0.5, "description": "bad category"}])
    monkeypatch.setattr(llm_service, "call_claude", lambda *a, **k: f"```json\n{reply}\n```")
    pid = _project(client)
    res = client.post(f"/api/projects/{pid}/llm-analysis").json()
    assert res["findings"] == 1 and not res["errors"]
    f = client.get(f"/api/projects/{pid}/findings").json()
    assert len(f) == 1 and f[0]["status"] == "Unverified" and "os.system" in f[0]["code"]
    stats = client.get("/api/dashboard/stats").json()
    assert stats["by_severity"].get("High", 0) >= 1 and stats["by_category"].get("Command Injection", 0) >= 1


def test_api_error_is_reported_without_key(client, monkeypatch):
    client.put("/api/settings/llm-key", json={"api_key": KEY})
    def boom(*a, **k):
        raise llm_service.LLMError("Claude API returned 401: invalid x-api-key")
    monkeypatch.setattr(llm_service, "call_claude", boom)
    res = client.post(f"/api/projects/{_project(client)}/llm-analysis").json()
    assert res["errors"] and KEY not in json.dumps(res)
