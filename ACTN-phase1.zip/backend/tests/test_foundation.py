import io, zipfile
from app.agents.base_agent import AgentStatus, BaseAgent, ProjectContext


def _zip(files: dict[str, str]) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        for k, v in files.items():
            z.writestr(k, v)
    return buf.getvalue()


def test_health_and_agents_seeded(client):
    assert client.get("/api/health").json() == {"status": "ok"}
    assert len(client.get("/api/agents").json()) == 9


def test_upload_zip_dedupes_and_counts(client):
    z = _zip({"a.py": "print(1)\n", "sub/b.py": "print(1)\n", "c.py": "x=2\n", "notes.txt": "hi"})
    r = client.post("/api/projects", data={"name": "demo", "language": "python"}, files=[("files", ("p.zip", z))])
    assert r.status_code == 201, r.text
    body = r.json()
    assert body["ingestion"]["stored"] == 2 and body["ingestion"]["duplicates_removed"] == 1
    assert body["job"]["status"] == "pending"
    files = client.get(f"/api/projects/{body['project']['id']}/files").json()
    assert len(files) == 2
    contents = [client.get(f"/api/files/{f['id']}").json()["content"] for f in files]
    assert any("x=2" in c for c in contents)


def test_zip_slip_rejected(client):
    z = _zip({"../../evil.py": "print(1)"})
    r = client.post("/api/projects", data={"name": "evil"}, files=[("files", ("e.zip", z))])
    assert r.status_code == 400


def test_unsupported_only_upload_rejected(client):
    r = client.post("/api/projects", data={"name": "x"}, files=[("files", ("a.txt", b"hello"))])
    assert r.status_code == 400


def test_settings_validation(client):
    bad = client.get("/api/settings").json()
    bad["crac_weights"] = {"semantic_relevance": 0.9, "dependency_exposure": 0.9, "execution_sensitivity": 0.9}
    assert client.put("/api/settings", json=bad).status_code == 422
    good = client.get("/api/settings").json()
    assert client.put("/api/settings", json=good).status_code == 200


def test_dashboard_counts_are_real(client):
    s = client.get("/api/dashboard/stats").json()
    assert s["vulnerabilities"] == 0 and s["projects"] >= 1


class Boom(BaseAgent):
    key = "boom"; name = "Boom"
    def process(self, ctx, inbox):
        raise RuntimeError("x")


class Flaky(BaseAgent):
    key = "flaky"; name = "Flaky"; n = 0
    def process(self, ctx, inbox):
        self.n += 1
        if self.n < 2:
            raise RuntimeError("transient")
        return {"ok": True}, []


def test_agent_retry_and_failure_isolation():
    ctx = ProjectContext(project_id=1, job_id=1)
    assert Boom().run(ctx).status == AgentStatus.FAILED
    res = Flaky().run(ctx)
    assert res.status == AgentStatus.COMPLETED and res.attempt == 2
