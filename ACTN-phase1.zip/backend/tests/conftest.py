import os, tempfile
_tmp = tempfile.mkdtemp()
os.environ["ACTN_DATA_DIR"] = _tmp
os.environ["ACTN_DATABASE_URL"] = f"sqlite:///{_tmp}/test.db"
import pytest
from fastapi.testclient import TestClient
from app.main import app


@pytest.fixture(scope="session")
def client():
    with TestClient(app) as c:
        yield c
