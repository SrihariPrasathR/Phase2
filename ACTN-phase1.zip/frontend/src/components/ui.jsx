import { Loader2 } from 'lucide-react'

const tones = {
  green: 'bg-emerald-500/10 text-emerald-300 ring-emerald-500/30', red: 'bg-red-500/10 text-red-300 ring-red-500/30',
  orange: 'bg-orange-500/10 text-orange-300 ring-orange-500/30', yellow: 'bg-yellow-500/10 text-yellow-200 ring-yellow-500/30',
  blue: 'bg-sky-500/10 text-sky-300 ring-sky-500/30', slate: 'bg-slate-500/10 text-slate-300 ring-slate-500/30',
}
export const sevTone = { Critical: 'red', High: 'orange', Medium: 'yellow', Low: 'blue' }
export const sevColor = { Critical: '#f87171', High: '#fb923c', Medium: '#facc15', Low: '#38bdf8' }

export function Badge({ tone = 'slate', children }) {
  return <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ring-1 ring-inset ${tones[tone]}`}>{children}</span>
}
export function PageHeader({ title, subtitle, children }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div><h1 className="text-2xl font-semibold tracking-tight text-slate-50">{title}</h1>
        {subtitle && <p className="mt-1 max-w-2xl text-sm text-slate-400">{subtitle}</p>}</div>
      <div className="flex gap-2">{children}</div>
    </div>
  )
}
export function StatCard({ label, value, icon: Icon, tone = 'slate' }) {
  const ring = { green: 'text-emerald-400 bg-emerald-500/10', red: 'text-red-400 bg-red-500/10', orange: 'text-orange-400 bg-orange-500/10',
    blue: 'text-sky-400 bg-sky-500/10', slate: 'text-slate-400 bg-slate-500/10', yellow: 'text-yellow-300 bg-yellow-500/10' }[tone]
  return (
    <div className="panel flex items-center gap-3 p-4">
      <div className={`rounded-lg p-2.5 ${ring}`}><Icon size={18} /></div>
      <div><div className="text-2xl font-semibold leading-none text-slate-50">{value ?? '–'}</div>
        <div className="mt-1 text-xs text-slate-500">{label}</div></div>
    </div>
  )
}
export function EmptyState({ icon: Icon, title, text, children }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-slate-700 px-6 py-10 text-center">
      {Icon && <Icon className="mb-3 text-slate-600" size={28} />}
      <div className="font-medium text-slate-300">{title}</div>
      {text && <p className="mt-1 max-w-sm text-sm text-slate-500">{text}</p>}
      {children && <div className="mt-4">{children}</div>}
    </div>
  )
}
export const Spinner = ({ label = 'Loading…' }) => (
  <div className="flex items-center gap-2 text-slate-400"><Loader2 className="animate-spin" size={16} />{label}</div>
)
export const Alert = ({ ok, children }) => (
  <div role="status" className={`rounded-lg px-3 py-2 text-sm ring-1 ring-inset ${ok ? 'bg-emerald-500/10 text-emerald-300 ring-emerald-500/30' : 'bg-red-500/10 text-red-300 ring-red-500/30'}`}>{children}</div>
)
