import { useRef, useState } from 'react'
import { FileCode2, UploadCloud, X } from 'lucide-react'

export default function Dropzone({ files, setFiles }) {
  const ref = useRef(null)
  const [over, setOver] = useState(false)
  const add = (list) => setFiles([...files, ...[...list].filter((f) => /\.(zip|py)$/i.test(f.name))])
  return (
    <div>
      <div onClick={() => ref.current.click()} onDragOver={(e) => { e.preventDefault(); setOver(true) }} onDragLeave={() => setOver(false)}
        onDrop={(e) => { e.preventDefault(); setOver(false); add(e.dataTransfer.files) }}
        className={`flex cursor-pointer flex-col items-center rounded-xl border-2 border-dashed px-6 py-10 text-center transition ${over ? 'border-emerald-400 bg-emerald-500/5' : 'border-slate-700 hover:border-slate-500'}`}>
        <UploadCloud className="mb-2 text-emerald-400" size={30} />
        <div className="font-medium">Drop a ZIP or .py files here</div>
        <div className="text-sm text-slate-500">or click to browse</div>
        <input ref={ref} type="file" multiple accept=".zip,.py" hidden onChange={(e) => add(e.target.files)} />
      </div>
      {files.length > 0 && (
        <ul className="mt-3 space-y-1">
          {files.map((f, i) => (
            <li key={i} className="panel flex items-center gap-2 px-3 py-2 text-sm">
              <FileCode2 size={15} className="text-slate-500" /><span className="truncate">{f.name}</span>
              <span className="ml-auto text-xs text-slate-500">{(f.size / 1024).toFixed(1)} KB</span>
              <button aria-label="Remove" onClick={() => setFiles(files.filter((_, j) => j !== i))} className="text-slate-500 hover:text-red-400"><X size={14} /></button>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
