import { Hourglass } from 'lucide-react'
import { EmptyState, PageHeader } from './ui.jsx'

export default function Pending({ title, phase }) {
  return (
    <div>
      <PageHeader title={title} />
      <EmptyState icon={Hourglass} title={`Planned for ${phase}`}
        text="The backend data this page needs does not exist yet, so nothing is shown rather than fake data." />
    </div>
  )
}
