import { useEffect, useState } from 'react'
export function useApi(fn, deps = []) {
  const [state, set] = useState({ data: null, error: null, loading: true })
  useEffect(() => {
    let alive = true
    fn().then((data) => alive && set({ data, error: null, loading: false }))
        .catch((error) => alive && set({ data: null, error: error.message, loading: false }))
    return () => { alive = false }
  }, deps)
  return state
}
