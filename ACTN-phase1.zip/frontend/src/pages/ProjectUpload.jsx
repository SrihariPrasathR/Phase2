import { useState } from 'react'
import { Link } from 'react-router-dom'
import Dropzone from '../components/Dropzone.jsx'
import { Alert, PageHeader } from '../components/ui.jsx'
import { api } from '../services/api.js'

export default function ProjectUpload() {
  const [name, setName] = useState('')
  const [language, setLanguage] = useState('python')
  const [files, setFiles] = useState([])
  const [msg, setMsg] = useState(null)
  const [busy, setBusy] = useState(false)

  async function submit() {
    setBusy(true); setMsg(null)
    try {
      const r = await api.upload(name, language, files)
      setMsg({ ok: true, text: `Project #${r.project.id} created: ${r.ingestion.stored} files stored, ${r.ingestion.duplicates_removed} duplicates removed.` })
      setFiles([]); setName('')
    } catch (e) { setMsg({ ok: false, text: e.message }) } finally { setBusy(false) }
  }
  return (
    <div className="max-w-2xl">
      <PageHeader title="Project Upload" subtitle="Upload only code you are authorised to analyse. Archives are validated and extracted safely." />
      <div className="panel space-y-4 p-5">
        <div><label className="label" htmlFor="pn">Project name</label>
          <input id="pn" className="input" placeholder="e.g. payments-service" value={name} onChange={(e) => setName(e.target.value)} /></div>
        <div><label className="label" htmlFor="pl">Language</label>
          <select id="pl" className="input" value={language} onChange={(e) => setLanguage(e.target.value)}><option value="python">Python</option></select></div>
        <Dropzone files={files} setFiles={setFiles} />
        <button disabled={busy || !name.trim() || !files.length} onClick={submit} className="btn-primary w-full">{busy ? 'Uploading…' : 'Upload project'}</button>
        {msg && <Alert ok={msg.ok}>{msg.text} {msg.ok && <Link to="/llm" className="font-medium underline">Analyze with Claude →</Link>}</Alert>}
      </div>
    </div>
  )
}
