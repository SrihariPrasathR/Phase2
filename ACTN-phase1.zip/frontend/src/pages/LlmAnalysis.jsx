import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Sparkles } from 'lucide-react'
import { Alert, Badge, EmptyState, PageHeader, sevTone } from '../components/ui.jsx'
import { api } from '../services/api.js'

export default function LlmAnalysis() {
  const [projects, setProjects] = useState([])
  const [pid, setPid] = useState('')
  const [findings, setFindings] = useState([])
  const [sev, setSev] = useState('All')
  const [busy, setBusy] = useState(false)
  const [msg, setMsg] = useState(null)

  useEffect(() => { api.projects().then((p) => { setProjects(p); if (p[0]) setPid(String(p[0].id)) }) }, [])
  useEffect(() => { if (pid) api.findings(pid).then(setFindings).catch(() => setFindings([])) }, [pid])

  async function run() {
    setBusy(true); setMsg(null)
    try {
      const r = await api.runLlm(pid)
      setFindings(await api.findings(pid))
      setMsg({ ok: !r.errors.length, text: `${r.files_analyzed} files analyzed with ${r.model}: ${r.findings} findings.` + (r.errors.length ? ` Errors: ${r.errors.map((e) => `${e.file}: ${e.error}`).join('; ')}` : '') })
    } catch (e) { setMsg({ ok: false, text: e.message }) } finally { setBusy(false) }
  }
  const shown = findings.filter((f) => sev === 'All' || f.severity === sev)
  return (
    <div className="space-y-4">
      <PageHeader title="Claude Analysis" subtitle="Findings are unverified candidates until sandbox evidence exists (Phase 4)." />
      {!projects.length ? (
        <EmptyState icon={Sparkles} title="No projects to analyze" text="Upload a project first."><Link to="/upload" className="btn-primary">Upload project</Link></EmptyState>
      ) : (<>
        <div className="panel flex flex-wrap items-center gap-3 p-3">
          <select aria-label="Project" value={pid} onChange={(e) => setPid(e.target.value)} className="input max-w-xs">
            {projects.map((p) => <option key={p.id} value={p.id}>#{p.id} {p.name} ({p.file_count} files)</option>)}</select>
          <button disabled={!pid || busy} onClick={run} className="btn-primary"><Sparkles size={15} />{busy ? 'Analyzing…' : 'Analyze with Claude'}</button>
          <div className="ml-auto flex gap-1">{['All', 'Critical', 'High', 'Medium', 'Low'].map((s) => (
            <button key={s} onClick={() => setSev(s)} className={`rounded-full px-3 py-1 text-xs ${sev === s ? 'bg-emerald-500/15 text-emerald-300' : 'text-slate-400 hover:bg-slate-800'}`}>{s}</button>))}</div>
        </div>
        {msg && <Alert ok={msg.ok}>{msg.text}</Alert>}
        <div className="space-y-3">
          {shown.map((f) => (
            <article key={f.id} className="panel p-4">
              <div className="flex flex-wrap items-center gap-2">
                <Badge tone={sevTone[f.severity]}>{f.severity}</Badge><h3 className="font-medium">{f.category}</h3>
                <code className="text-xs text-slate-400">{f.file}:{f.line}{f.function ? ` · ${f.function}()` : ''}</code>
                <span className="ml-auto flex items-center gap-2 text-xs text-slate-500">{(f.confidence * 100).toFixed(0)}% confidence <Badge>{f.status}</Badge></span>
              </div>
              <p className="mt-2 text-sm text-slate-300">{f.description}</p>
              <pre className="mt-2 overflow-auto rounded-lg border border-red-500/20 bg-slate-950 p-2.5 text-xs text-amber-200">{f.code}</pre>
              {f.remediation && <p className="mt-2 rounded-lg bg-emerald-500/5 p-2.5 text-sm text-emerald-300"><b>Fix:</b> {f.remediation}</p>}
            </article>))}
          {!shown.length && <EmptyState icon={Sparkles} title="No findings to show" text="Run the analysis, or change the severity filter." />}
        </div>
      </>)}
    </div>
  )
}
