import { useEffect, useState } from 'react'
import { Eye, EyeOff, KeyRound } from 'lucide-react'
import { Alert, Badge, PageHeader, Spinner } from '../components/ui.jsx'
import { api } from '../services/api.js'

export default function Settings() {
  const [cfg, setCfg] = useState(null)
  const [key, setKey] = useState('')
  const [show, setShow] = useState(false)
  const [status, setStatus] = useState(null)
  const [msg, setMsg] = useState(null)

  useEffect(() => {
    Promise.all([api.settings(), api.keyStatus()]).then(([c, k]) => { setCfg(c); setStatus(k) })
      .catch((e) => setMsg({ ok: false, text: e.message }))
  }, [])
  const run = async (fn, okText) => { try { await fn(); setMsg({ ok: true, text: okText }) } catch (e) { setMsg({ ok: false, text: e.message }) } }

  if (!cfg) return msg ? <Alert>{msg.text}</Alert> : <Spinner />
  const w = cfg.crac_weights
  return (
    <div className="max-w-3xl space-y-6">
      <PageHeader title="Settings" subtitle="Configure the Claude integration and review analysis defaults." />
      {msg && <Alert ok={msg.ok}>{msg.text}</Alert>}
      <section className="panel space-y-4 p-5">
        <div className="flex items-center gap-2"><KeyRound size={18} className="text-emerald-400" /><h2 className="font-semibold">Claude API</h2>
          {status?.configured ? <Badge tone="green">configured {status.hint}</Badge> : <Badge tone="yellow">no key set</Badge>}</div>
        <p className="text-sm text-slate-400">The key is stored on the backend only and never sent back to the browser. Your code is sent to the Anthropic API when you run an analysis.</p>
        <div><label className="label" htmlFor="k">API key</label>
          <div className="relative"><input id="k" className="input pr-10" type={show ? 'text' : 'password'} autoComplete="off" placeholder="sk-ant-…" value={key} onChange={(e) => setKey(e.target.value)} />
            <button type="button" aria-label="Toggle visibility" onClick={() => setShow(!show)} className="absolute right-2 top-2 text-slate-500 hover:text-slate-300">{show ? <EyeOff size={16} /> : <Eye size={16} />}</button></div></div>
        <div className="flex gap-2">
          <button disabled={!key} className="btn-primary" onClick={() => run(async () => { setStatus(await api.setKey(key)); setKey('') }, 'API key saved on the server.')}>Save key</button>
          {status?.configured && <button className="btn-ghost" onClick={() => run(async () => setStatus(await api.deleteKey()), 'API key removed.')}>Remove key</button>}
        </div>
        <div><label className="label" htmlFor="m">Model</label>
          <div className="flex gap-2"><input id="m" className="input" value={cfg.llm.model} onChange={(e) => setCfg({ ...cfg, llm: { ...cfg.llm, model: e.target.value } })} />
            <button className="btn-ghost" onClick={() => run(async () => setCfg(await api.saveSettings(cfg)), 'Model saved.')}>Save</button></div></div>
      </section>
      <section className="panel p-5">
        <h2 className="mb-3 font-semibold">CRAC weights <span className="text-xs font-normal text-slate-500">(engineering assumption – not from the paper)</span></h2>
        {[['Semantic relevance', w.semantic_relevance], ['Dependency exposure', w.dependency_exposure], ['Execution sensitivity', w.execution_sensitivity]].map(([l, v]) => (
          <div key={l} className="mb-2"><div className="flex justify-between text-sm"><span className="text-slate-300">{l}</span><span className="text-slate-400">{v.toFixed(2)}</span></div>
            <div className="mt-1 h-2 rounded bg-slate-800"><div className="h-2 rounded bg-emerald-500" style={{ width: `${v * 100}%` }} /></div></div>))}
        <p className="mt-3 text-xs text-slate-500">Thresholds – Critical ≥ {cfg.risk_thresholds.critical}, High ≥ {cfg.risk_thresholds.high}, Medium ≥ {cfg.risk_thresholds.medium}. Editing arrives in Phase 5.</p>
      </section>
    </div>
  )
}
