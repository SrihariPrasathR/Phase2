import { Link } from 'react-router-dom'
import { Bar, BarChart, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { BadgeCheck, Bot, Bug, CheckCircle2, FileCode2, FlaskConical, FolderGit2, HelpCircle, ShieldAlert, XCircle } from 'lucide-react'
import { Alert, Badge, EmptyState, PageHeader, Spinner, StatCard, sevColor } from '../components/ui.jsx'
import { useApi } from '../hooks/useApi.js'
import { api } from '../services/api.js'

const tip = { contentStyle: { background: '#0f172a', border: '1px solid #1e293b', borderRadius: 8, fontSize: 12 } }

export default function Dashboard() {
  const { data: s, error, loading } = useApi(api.stats)
  const { data: projects } = useApi(api.projects)
  const { data: agents } = useApi(api.agents)
  if (loading) return <Spinner />
  if (error) return <Alert>Backend unreachable: {error}. Start it with <code>uvicorn app.main:app --port 8000</code>.</Alert>

  const sev = Object.entries(s.by_severity).map(([name, value]) => ({ name, value }))
  const cat = Object.entries(s.by_category).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value)
  return (
    <div className="space-y-6">
      <PageHeader title="Security Operations Dashboard" subtitle="Live overview of projects, findings and verification results.">
        <Link to="/upload" className="btn-primary">New analysis</Link>
      </PageHeader>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
        <StatCard label="Projects" value={s.projects} icon={FolderGit2} tone="blue" />
        <StatCard label="Files scanned" value={s.files} icon={FileCode2} tone="blue" />
        <StatCard label="Vulnerabilities" value={s.vulnerabilities} icon={Bug} tone="orange" />
        <StatCard label="Confirmed" value={s.confirmed} icon={ShieldAlert} tone="red" />
        <StatCard label="Potential" value={s.potential} icon={HelpCircle} tone="yellow" />
        <StatCard label="False positives" value={s.false_positives} icon={BadgeCheck} tone="green" />
        <StatCard label="Tests generated" value={s.tests_generated} icon={FlaskConical} />
        <StatCard label="Tests passed" value={s.tests_passed} icon={CheckCircle2} tone="green" />
        <StatCard label="Tests failed" value={s.tests_failed} icon={XCircle} tone="red" />
        <StatCard label="Agents" value={s.agents} icon={Bot} tone="green" />
      </div>

      <section className="panel p-4">
        <h2 className="mb-3 text-sm font-semibold text-slate-300">Agent pipeline</h2>
        <div className="flex gap-2 overflow-x-auto pb-1">
          {(agents ?? []).map((a, i) => (
            <div key={a.key} className="flex shrink-0 items-center gap-2">
              <div className="rounded-lg border border-slate-800 bg-slate-950 px-3 py-2">
                <div className="text-[10px] text-slate-600">STEP {i + 1}</div>
                <div className="text-xs font-medium text-slate-300">{a.name.replace(' Agent', '')}</div>
                <div className="mt-1"><Badge>{a.status}</Badge></div>
              </div>
              {i < agents.length - 1 && <span className="text-slate-700">→</span>}
            </div>
          ))}
        </div>
      </section>

      <div className="grid gap-4 lg:grid-cols-2">
        <section className="panel p-4">
          <h2 className="mb-3 text-sm font-semibold text-slate-300">Findings by severity</h2>
          {sev.length ? (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart><Pie data={sev} dataKey="value" nameKey="name" innerRadius={55} outerRadius={85} paddingAngle={3} stroke="none">
                {sev.map((d) => <Cell key={d.name} fill={sevColor[d.name] ?? '#64748b'} />)}</Pie><Tooltip {...tip} /></PieChart>
            </ResponsiveContainer>
          ) : <EmptyState icon={ShieldAlert} title="No findings yet" text="Run a Claude analysis on a project to populate this chart." />}
          <div className="mt-2 flex flex-wrap gap-3 text-xs text-slate-400">
            {sev.map((d) => <span key={d.name} className="flex items-center gap-1"><i className="h-2 w-2 rounded-full" style={{ background: sevColor[d.name] }} />{d.name} {d.value}</span>)}
          </div>
        </section>
        <section className="panel p-4">
          <h2 className="mb-3 text-sm font-semibold text-slate-300">Findings by category</h2>
          {cat.length ? (
            <ResponsiveContainer width="100%" height={Math.max(220, cat.length * 34)}>
              <BarChart data={cat} layout="vertical" margin={{ left: 40 }}>
                <XAxis type="number" allowDecimals={false} stroke="#475569" fontSize={11} />
                <YAxis type="category" dataKey="name" width={150} stroke="#475569" fontSize={11} />
                <Tooltip {...tip} cursor={{ fill: '#1e293b' }} /><Bar dataKey="value" fill="#34d399" radius={4} />
              </BarChart>
            </ResponsiveContainer>
          ) : <EmptyState icon={Bug} title="No categories to show" text="Categories appear once findings exist." />}
        </section>
      </div>

      <section className="panel overflow-hidden">
        <h2 className="border-b border-slate-800 p-4 text-sm font-semibold text-slate-300">Recent projects</h2>
        {projects?.length ? (
          <table className="w-full text-sm">
            <thead className="bg-slate-900 text-left text-xs uppercase tracking-wide text-slate-500">
              <tr><th className="px-4 py-2">Name</th><th>Language</th><th>Files</th><th>Job</th><th /></tr></thead>
            <tbody>{projects.slice(0, 8).map((p) => (
              <tr key={p.id} className="border-t border-slate-800 hover:bg-slate-800/40">
                <td className="px-4 py-2.5 font-medium">{p.name}</td><td className="capitalize text-slate-400">{p.language}</td>
                <td>{p.file_count}</td>
                <td><Badge tone={p.latest_job?.status === 'completed' ? 'green' : p.latest_job?.status === 'failed' ? 'red' : 'slate'}>{p.latest_job?.status ?? '–'}</Badge></td>
                <td className="pr-4 text-right"><Link className="text-emerald-400 hover:underline" to="/llm">Analyze →</Link></td>
              </tr>))}</tbody>
          </table>
        ) : <div className="p-4"><EmptyState icon={FolderGit2} title="No projects yet" text="Upload a ZIP or Python files to get started."><Link to="/upload" className="btn-primary">Upload project</Link></EmptyState></div>}
      </section>
    </div>
  )
}
