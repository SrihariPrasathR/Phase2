import { Bot } from 'lucide-react'
import { Badge, PageHeader, Spinner } from '../components/ui.jsx'
import { useApi } from '../hooks/useApi.js'
import { api } from '../services/api.js'

export default function Agents() {
  const { data, loading } = useApi(api.agents)
  if (loading) return <Spinner />
  return (
    <div>
      <PageHeader title="Agent Monitoring" subtitle="Registered agents. Live task, duration and message history appear once the orchestrator exists (Phase 2)." />
      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {data.map((a, i) => (
          <div key={a.key} className="panel p-4">
            <div className="mb-2 flex items-center gap-2"><div className="rounded-lg bg-emerald-500/10 p-2 text-emerald-400"><Bot size={16} /></div>
              <div className="text-xs text-slate-600">AGENT {i + 1}</div><span className="ml-auto"><Badge>{a.status}</Badge></span></div>
            <div className="font-medium">{a.name}</div><p className="mt-1 text-sm text-slate-400">{a.description}</p>
          </div>))}
      </div>
    </div>
  )
}
