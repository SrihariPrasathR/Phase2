import { useEffect, useState } from 'react'
import { NavLink, Outlet } from 'react-router-dom'
import { Activity, Bot, Bug, Code2, FileText, FlaskConical, LayoutDashboard, Menu, Settings, ShieldCheck, Sparkles, Upload, X } from 'lucide-react'
import { health } from '../services/api.js'

const groups = [
  ['Overview', [['/', 'Dashboard', LayoutDashboard]]],
  ['Analysis', [['/upload', 'Project Upload', Upload], ['/llm', 'Claude Analysis', Sparkles], ['/progress', 'Analysis Progress', Activity],
                ['/vulnerabilities', 'Vulnerability Explorer', Bug], ['/source', 'Source Viewer', Code2]]],
  ['Operations', [['/agents', 'Agent Monitoring', Bot], ['/tests', 'Test Execution', FlaskConical], ['/reports', 'Reports', FileText]]],
  ['System', [['/settings', 'Settings', Settings]]],
]

export default function MainLayout() {
  const [open, setOpen] = useState(false)
  const [up, setUp] = useState(null)
  useEffect(() => { const t = () => health().then(setUp); t(); const id = setInterval(t, 10000); return () => clearInterval(id) }, [])
  return (
    <div className="min-h-screen lg:flex">
      <div className="flex items-center justify-between border-b border-slate-800 p-3 lg:hidden">
        <div className="flex items-center gap-2 font-bold text-emerald-400"><ShieldCheck size={20} />ACTN-CRAC</div>
        <button aria-label="Menu" onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</button>
      </div>
      <aside className={`${open ? 'block' : 'hidden'} w-full shrink-0 border-slate-800 bg-slate-900/60 p-4 lg:sticky lg:top-0 lg:block lg:h-screen lg:w-64 lg:overflow-y-auto lg:border-r`}>
        <div className="mb-6 hidden items-center gap-2 lg:flex">
          <div className="rounded-lg bg-emerald-500/15 p-1.5 text-emerald-400"><ShieldCheck size={20} /></div>
          <div><div className="font-bold leading-none tracking-wide text-slate-50">ACTN-CRAC</div>
            <div className="text-[11px] text-slate-500">Cooperative Testing Network</div></div>
        </div>
        {groups.map(([title, items]) => (
          <div key={title} className="mb-4">
            <div className="mb-1 px-3 text-[11px] font-semibold uppercase tracking-wider text-slate-600">{title}</div>
            {items.map(([to, label, Icon]) => (
              <NavLink key={to} to={to} end={to === '/'} onClick={() => setOpen(false)}
                className={({ isActive }) => `flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm transition ${isActive ? 'bg-emerald-500/10 text-emerald-300 ring-1 ring-inset ring-emerald-500/20' : 'text-slate-400 hover:bg-slate-800/70 hover:text-slate-200'}`}>
                <Icon size={16} />{label}
              </NavLink>
            ))}
          </div>
        ))}
        <div className="mt-6 flex items-center gap-2 rounded-lg border border-slate-800 px-3 py-2 text-xs text-slate-400">
          <span className={`h-2 w-2 rounded-full ${up === null ? 'bg-slate-600' : up ? 'bg-emerald-400 pulse-dot' : 'bg-red-500'}`} />
          Backend {up === null ? 'checking…' : up ? 'online' : 'offline'}
        </div>
      </aside>
      <main className="min-w-0 flex-1 p-4 sm:p-8"><div className="mx-auto max-w-6xl"><Outlet /></div></main>
    </div>
  )
}
