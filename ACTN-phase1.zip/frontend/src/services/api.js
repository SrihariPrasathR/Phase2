async function req(path, opts) {
  const res = await fetch('/api' + path, opts)
  if (!res.ok) {
    let detail = res.statusText
    try { detail = (await res.json()).detail ?? detail } catch {}
    throw new Error(typeof detail === 'string' ? detail : JSON.stringify(detail))
  }
  return res.json()
}
export const api = {
  stats: () => req('/dashboard/stats'),
  agents: () => req('/agents'),
  projects: () => req('/projects'),
  settings: () => req('/settings'),
  saveSettings: (s) => req('/settings', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(s) }),
  keyStatus: () => req('/settings/llm-key'),
  setKey: (api_key) => req('/settings/llm-key', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ api_key }) }),
  deleteKey: () => req('/settings/llm-key', { method: 'DELETE' }),
  runLlm: (id) => req(`/projects/${id}/llm-analysis`, { method: 'POST' }),
  findings: (id) => req(`/projects/${id}/findings`),
  upload: (name, language, files) => {
    const fd = new FormData(); fd.append('name', name); fd.append('language', language)
    files.forEach((f) => fd.append('files', f))
    return req('/projects', { method: 'POST', body: fd })
  },
}
export const health = () => fetch('/api/health').then((r) => r.ok).catch(() => false)
