import { Route, Routes } from 'react-router-dom'
import MainLayout from './layouts/MainLayout.jsx'
import Dashboard from './pages/Dashboard.jsx'
import ProjectUpload from './pages/ProjectUpload.jsx'
import Settings from './pages/Settings.jsx'
import LlmAnalysis from './pages/LlmAnalysis.jsx'
import Agents from './pages/Agents.jsx'
import Pending from './components/Pending.jsx'

export default function App() {
  return (
    <Routes>
      <Route element={<MainLayout />}>
        <Route index element={<Dashboard />} />
        <Route path="upload" element={<ProjectUpload />} />
        <Route path="llm" element={<LlmAnalysis />} />
        <Route path="progress" element={<Pending title="Analysis Progress" phase="Phase 5 (needs the Phase 2 orchestrator)" />} />
        <Route path="vulnerabilities" element={<Pending title="Vulnerability Explorer" phase="Phase 5 (needs Phase 3 analysis)" />} />
        <Route path="source" element={<Pending title="Source Code Viewer" phase="Phase 5" />} />
        <Route path="agents" element={<Agents />} />
        <Route path="tests" element={<Pending title="Test Execution" phase="Phase 5 (needs Phase 4 sandbox)" />} />
        <Route path="reports" element={<Pending title="Reports" phase="Phase 5" />} />
        <Route path="settings" element={<Settings />} />
      </Route>
    </Routes>
  )
}
